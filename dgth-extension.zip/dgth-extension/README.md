# DGTH Study Panel

A Chrome/Edge side panel for studying. It stays open next to whatever page you're reading, so you don't have to bounce between tabs.

- **Ask:** look up a word, get a quick answer to factual questions ("who wrote Romeo and Juliet", "when was Einstein born", "capital of Japan"), read a Wikipedia summary, or do math. Add your own Anthropic API key in Settings for full AI explanations.
- **Right-click lookup:** select text on any page, right-click, and choose "Look up in DGTH".
- **Notes:** autosaved. Use "Add to notes" on any result. Copy or download as .txt.
- **Cards:** make your own flashcards, flip, shuffle, delete.
- **Timer:** 25 minute focus and 5 minute break timers that keep running if you close the panel.

## Install (Chrome, Edge, Brave)

1. Download or clone this folder.
2. Open `chrome://extensions` and turn on **Developer mode**.
3. Click **Load unpacked** and select this folder.
4. Click the DGTH icon in the toolbar to open the panel.

Requires Chrome 114 or newer.

## Privacy

- Notes, cards and settings are stored with `chrome.storage.local`, in your browser only.
- Lookups go to Wikipedia, Wikidata and dictionaryapi.dev. AI answers go to api.anthropic.com, only if you add a key.
- Your API key is stored locally and never leaves your browser except in requests to Anthropic. Never commit a key to this repo.

## Use it honestly

DGTH is a visible, normal side panel. It's built for studying, homework and research where those tools are allowed. Follow your teacher's and school's rules for quizzes and tests. If a test is closed-book, close the panel.
